# Deploying Talent Match & Blurb Studio publicly (100% free)

This folder is a complete, ready-to-deploy Cloudflare Pages site:
- `index.html` — the app itself
- `functions/api/blurb.js` — a small server-side function that generates
  blurbs using **Cloudflare Workers AI**, which is free (10,000 requests/day
  included on every Cloudflare account) and needs **no credit card, no API
  key, and no billing setup of any kind**.

## 1. Deploy to Cloudflare Pages
1. Go to https://dash.cloudflare.com and sign up for a free account (email
   only — no card required).
2. Go to **Workers & Pages → Create → Pages → Upload assets**, and select
   this whole folder (`index.html` and the `functions` folder together).
   - If you'd rather connect a GitHub repo instead, push this folder to a repo
     and choose "Connect to Git" — Cloudflare auto-detects the `functions/`
     folder as Pages Functions, no build configuration needed.
3. Give the project a name (e.g. `talent-match-studio`) and deploy.

## 2. Turn on the free AI binding (no key needed)
1. In your deployed project, go to **Settings → Functions → AI bindings**.
2. Click **Add binding**:
   - Variable name: `AI`
   - Nothing else to fill in — no key, no account ID, no billing.
3. Go to the **Deployments** tab and redeploy (or push a new commit) so the
   function picks up the binding.

## 3. Done
Your Pages URL (something like `https://talent-match-studio.pages.dev`) is
now public. Anyone with the link can open it and generate blurbs — no
install, no per-person setup, and there is nothing to pay, ever, within the
free daily allowance.

## How the free tier holds up
- Every Cloudflare account gets **10,000 free "neurons" per day**, resetting
  at midnight UTC. The model used here (`llama-3.2-3b-instruct`) is a small,
  fast model chosen specifically to stretch that allowance — each blurb
  should use a small fraction of the daily budget, comfortably covering
  normal team usage.
- If you ever see errors mentioning a rate or neuron limit, it means the
  daily free allowance was used up for that day; it resets automatically at
  00:00 UTC and costs nothing either way — Cloudflare will not silently
  start charging you.
- If blurb quality isn't good enough with the small model, open
  `functions/api/blurb.js` and change the `MODEL` constant to
  `"@cf/meta/llama-3.1-8b-instruct"` for noticeably better output (uses more
  of the daily allowance per call, but still free within the limit).

## Notes
- There's no login on this page — anyone with the link can use it. If that's
  a concern, Cloudflare Pages supports **Cloudflare Access** (Settings →
  your project → Access policies) to put the whole site behind an email/SSO
  login for free, without touching the code.
- If you'd rather use Vercel or Netlify instead of Cloudflare, say so —
  Workers AI is Cloudflare-specific, so on another platform you'd need a
  different free model source (e.g. Google's Gemini free tier or Groq's free
  tier), and I can rewrite `functions/api/blurb.js` accordingly.
